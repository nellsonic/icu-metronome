# Pages Rescue Kit (docs/)

Upload this entire `docs/` folder to your repo root, then set:
Settings → Pages → Build and deployment → Source = Deploy from a branch
Branch = main, Folder = /docs

Open your site and click “Features Guide”.
