---
title: ICU Metronome
---

# ICU Metronome

This is a clean test deploy (created 2025-08-11T10:01:39).  
Use the link below to verify your new Features page is live.

- 👉 **[Features Guide](/features/)**

If you see this page online, GitHub Pages is working from **/docs**. Then the Features link should show your updated text.
