---
title: ICU Metronome
---

# ICU Metronome

Welcome. This starter site is set up to deploy from **/docs** via GitHub Pages.

- 👉 **[Features Guide](/features/)**

*Generated on 2025-08-11 10:21:03.*
