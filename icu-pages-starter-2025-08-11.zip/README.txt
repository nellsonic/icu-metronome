ICU Pages Starter — Upload Instructions (No Actions Needed)

1) Create an empty repo (or delete all files from your current one).
2) Upload the entire `docs/` folder at the ROOT of the repo.
   - You should see: `docs/index.md` and `docs/features.md` after upload.
3) In the repo: Settings → Pages → Build and deployment
   - Source: Deploy from a branch
   - Branch: main
   - Folder: /docs
   - Save
4) Wait ~30–60 seconds. Open your site URL and hard-refresh (Cmd/Ctrl+Shift+R).
   - Home page should show a link to “Features Guide”.
   - Clicking it should display your updated text.

Notes:
- Do NOT include a `.nojekyll` file; we want Jekyll to render Markdown.
- If you later prefer building from the repo root, move both files out of `docs` to `/` and set Pages Folder to “/ (root)”. Keep only one copy of `features.md` to avoid route conflicts.
